package com.keensmatz.abstraction;

public abstract class KIACeltos {
	
	abstract void wheel();
	
	void engine()
	{
		System.out.println(" I am a kia Engine");
	}
	
	
	

}
