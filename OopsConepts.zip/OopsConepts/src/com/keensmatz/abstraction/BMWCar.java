package com.keensmatz.abstraction;

public class BMWCar implements Car{
	
	

	@Override
	public void wheel() {
		// TODO Auto-generated method stub
		
		System.out.println(" I am a BMW Wheel");
		
	}

	@Override
	public void engine() {
		// TODO Auto-generated method stub
		

		System.out.println(" I am a BMW Engine having capacity 2500 cc");
		
	}
	
	void sunroof()
	{
		System.out.println(" I have sunroof feature");
	}

}
