package com.keensmatz.abstraction;

public class HyundaiCar implements Car{

	

	@Override
	public void wheel() {
		// TODO Auto-generated method stub
		
		System.out.println(" I am hyundai wheel have 13 * 14 size");
		
	}

	@Override
	public void engine() {
		// TODO Auto-generated method stub
		System.out.println(" I am hyundai engine have 1500 cc");
		
	}

}
