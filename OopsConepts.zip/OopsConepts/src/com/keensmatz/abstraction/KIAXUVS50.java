package com.keensmatz.abstraction;

public class KIAXUVS50  extends KIACeltos{

	@Override
	void wheel() {
		// TODO Auto-generated method stub
		
		System.out.println(" I am a KIA XuV Wheel");
		
	}

	
	public static void main(String[] args) {
		
		KIACeltos kobj = new KIAXUVS50();
		
		kobj.engine();
		kobj.wheel();
		
	}
}
