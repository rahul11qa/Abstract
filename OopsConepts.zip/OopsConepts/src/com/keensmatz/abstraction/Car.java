/**
 * 
 */
package com.keensmatz.abstraction;

/**
 * @author HPSpectre
 *
 */
public interface Car {
	
	abstract void wheel();
	abstract void engine();
	

}
