package com.keensmatz.abstraction;

public class MyCar {
	
	
	void wheel()
	{
		System.out.println(" I am a wheel");
	}
	
	void engine()
	{
		System.out.println(" I am a engine");
	}

}
