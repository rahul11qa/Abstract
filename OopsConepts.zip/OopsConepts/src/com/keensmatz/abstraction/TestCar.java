package com.keensmatz.abstraction;

public class TestCar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BMWCar bobj = new BMWCar();
		
		HyundaiCar bhbj = new HyundaiCar();
		
		bobj.engine();
		bobj.wheel();
		bobj.sunroof();
		
		bhbj.engine();
		bhbj.wheel();

	}

}
